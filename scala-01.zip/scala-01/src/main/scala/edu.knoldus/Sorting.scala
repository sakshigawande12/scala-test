package edu.knoldus

class Sorting {

  def insertionSort(list: List[Int]): List[Int] = ???

  def selectionSort(list: List[Int]): List[Int] = ???

  def bubbleSort(list: List[Int]): List[Int] = ???

}
